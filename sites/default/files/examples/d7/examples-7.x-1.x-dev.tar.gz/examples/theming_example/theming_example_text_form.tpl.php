<?php
/**
 * @file
 * Template file for theming_example_text_form
 *
 * The array $text_form_content contains the individual form components
 * To view them in the source html use this
 *
 * <?php print '<!--' . print_r($text_form_content, TRUE) . '-->'; ?>
 *
 */
?>
<!-- theming_example_text_form template -->
<div class="container-inline">
<?php  print $text_form; ?>
</div>
<!-- /theming_example_text_form template -->
