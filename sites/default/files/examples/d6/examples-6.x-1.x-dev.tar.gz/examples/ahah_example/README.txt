
AHAH example provides three simple examples of AHAH in Drupal 6.

There is a tutorial based on this module at http://randyfay.com/ahah.

1. simplest_ahah: A tremendously simple example that just swaps out a div when you click
   the submit button (simplest_ahah)
   
2. autocheckboxes: Regenerate a form with the number of checkboxes determined
   by a select pulldown.
   
3. autotextfields: Regenerate a form with various textfields based on whether
   a checkbox is clicked.